﻿using System.Collections.ObjectModel;
using System.Security.AccessControl;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ObservableCollection<Kostka> Kosci = new ObservableCollection<Kostka>();
        public MainWindow()
        {
            InitializeComponent();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int sumaOczek = 0;

            foreach (Kostka item in Kosci)
            {
                if (item.czyDostepna)
                {
                    item.losuj();
                    sumaOczek += item.Oczka;
                }
            }

            listView.Items.Refresh();

            sumaOczeklbl.Content = sumaOczek;
            sprawdzSzustki(sender, e);
        }

        private void losuj_Click(object sender, RoutedEventArgs e)
        {
            int ile;

            if (int.TryParse(ileKostk.Text, out ile) && ile > 0)
            {
                Kosci.Clear();

                for (int i = 0; i < ile; i++)
                {
                    Kosci.Add(new Kostka());
                    listView.ItemsSource = Kosci;
                }
            }

        }


        void sprawdzSzustki(object sender, RoutedEventArgs e)
        {
            int sumaSzustek = 0;

            foreach (Kostka item in Kosci)
            {
                if (item.Oczka == 6)
                {
                    sumaSzustek++;
                }
            }

            if (sumaSzustek == Kosci.Count && Kosci.Count > 0)
            {
                MessageBox.Show("Gratulacje! Wyrzuciłeś same szóstki!",
                                "Sukces",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
            }
        }

        private void Image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Image i = (Image)sender;

            Kostka k = (Kostka)i.DataContext;

            if(k.czyDostepna == true)
            {
                k.czyDostepna = false;
                i.Opacity = 0.5;
            }
            else
            {
                k.czyDostepna = true;
                i.Opacity = 1;

            }
        }
    }
}
 