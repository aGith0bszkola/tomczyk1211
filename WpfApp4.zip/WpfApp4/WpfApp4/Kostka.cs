﻿using System;

namespace WpfApp4
{
    internal class Kostka
    {
        public Kostka()
        {
            losuj();
            this.czyDostepna = true;
        }

        public void losuj()
        {
            Random r = new Random();
            Oczka = r.Next(1, 7);
            Obrazek = "/kosc" + Oczka + ".png";
        }

        public int Oczka { get; set; }
        public string Obrazek { get; set; }
        public bool czyDostepna { get; set; }
    }
}